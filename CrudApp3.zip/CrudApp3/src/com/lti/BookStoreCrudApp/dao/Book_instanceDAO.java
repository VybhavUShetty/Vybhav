package com.lti.BookStoreCrudApp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//import com.lti.BookStoreCrud.model.Author;
import com.lti.bookinstance.Book_instance;

public class Book_instanceDAO {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "ilovejava";

	private static final String INSERT_USERS_SQL = "INSERT INTO Book_instance VALUES "
		+ " (?,?, ?, ?)";

	private static final String SELECT_USER_BY_ID = "select  copy_instance,store_id,ISBN,"
			+ "order_detail_id from Book_instance where copy_instance =?";
	private static final String SELECT_ALL_USERS = "select * from copy_instance";
	private static final String DELETE_USERS_SQL = "delete from Book_instance where copy_instance = ?";
	private static final String UPDATE_USERS_SQL = "update Book_instance set store_id = ?,"
			+ "store_id= ?, ISBN =? where copy_instance = ?";

	public Book_instanceDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertUser(Book_instance user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_USERS_SQL);
			preparedStatement.setInt(1, user.getStore_id());
			preparedStatement.setInt(2, user.getISBN());
			preparedStatement.setInt(3, user.getOrder_detail_id());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Book_instance selectUser(int copy_instance) {
		Book_instance user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, copy_instance);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int store_id = rs.getInt("store_id");
				int ISBN = rs.getInt("ISBN");
				int order_detail_id = rs.getInt("order_detail_id");
				user = new Book_instance(store_id, ISBN, order_detail_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Book_instance> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Book_instance> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_USERS);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int copy_instance = rs.getInt(" copy_instance");
				int store_id = rs.getInt("store_id");
				int ISBN = rs.getInt("ISBN");
				int order_detail_id = rs.getInt("order_detail_id");
				users.add(new Book_instance(copy_instance,store_id, ISBN, order_detail_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int copy_instance) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_USERS_SQL);) {
			statement.setInt(1, copy_instance);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(Book_instance user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_USERS_SQL);) {
			statement.setInt(1, user.getCopy_instance());
			statement.setInt(2, user.getStore_id());
			statement.setInt(3, user.getISBN());
			statement.setInt(4, user.getOrder_detail_id());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
		}
	



