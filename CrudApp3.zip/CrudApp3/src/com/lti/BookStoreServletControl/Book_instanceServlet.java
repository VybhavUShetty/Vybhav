package com.lti.BookStoreServletControl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.lti.BookStoreCrudApp.dao.Book_instanceDAO;
import com.lti.bookinstance.Book_instance;



@WebServlet("/NNN")
public class Book_instanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Book_instanceDAO userDAO;
	
	public void init() {
		userDAO = new Book_instanceDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Book_instance> listUser = userDAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("author-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("author-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int copy_instance = Integer.parseInt(request.getParameter("copy_instance"));
		Book_instance existingUser = userDAO.selectUser(copy_instance);
		RequestDispatcher dispatcher = request.getRequestDispatcher("author-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int copy_instance = Integer.parseInt(request.getParameter("copy_instance"));
		int store_id = Integer.parseInt(request.getParameter("store_id"));
		int ISBN = Integer.parseInt(request.getParameter("ISBN"));
		int order_detail_id = Integer.parseInt(request.getParameter("order_detail_id"));
		Book_instance newUser = new Book_instance(copy_instance, store_id, ISBN);
		userDAO.insertUser(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int copy_instance = Integer.parseInt(request.getParameter("copy_instance"));
		int store_id = Integer.parseInt(request.getParameter("store_id"));
		int ISBN = Integer.parseInt(request.getParameter("ISBN"));
		int order_detail_id = Integer.parseInt(request.getParameter("order_detail_id"));

		Book_instance book = new Book_instance(copy_instance, store_id, ISBN, order_detail_id);
		userDAO.updateUser(book);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int AUTHOR_ID = Integer.parseInt(request.getParameter("AUTHOR_ID"));
		userDAO.deleteUser(AUTHOR_ID);
		response.sendRedirect("list");

	}

}
