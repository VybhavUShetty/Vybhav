package com.lti.bookinstance;



public class Book_instance {
	protected int copy_instance;
	protected int store_id;
	protected int ISBN;
	protected int order_detail_id;
	
	public Book_instance() {
	}
	
	

	public Book_instance(int copy_instance, int store_id, int iSBN, int order_detail_id) {
		super();
		this.copy_instance = copy_instance;
		this.store_id = store_id;
		this.ISBN = iSBN;
		this.order_detail_id = order_detail_id;
	}
	
	public Book_instance( int store_id, int iSBN, int order_detail_id) {
		super();
		
		this.store_id = store_id;
		this.ISBN = iSBN;
		this.order_detail_id = order_detail_id;
	}
	
	


	public int getCopy_instance() {
		
		return copy_instance;
	}
	

	public void setCopy_instance(int copy_instance) {
		this.copy_instance = copy_instance;
	}

	public int getStore_id() {
		return store_id;
	}

	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public int getOrder_detail_id() {
		return order_detail_id;
	}

	public void setOrder_detail_id(int order_detail_id) {
		this.order_detail_id = order_detail_id;
	}

	}

	
